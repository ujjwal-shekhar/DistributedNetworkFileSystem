# Network File System

## Team mates
- Anika Roy
- Prakul Agarwal
- Ujjwal Shekhar

# Usage instructions
- Clone the repository
```bash
git clone link ./name_of_the_directory
```

- Navigate to the directory
```bash
cd name_of_the_directory
```

- Run the Makefile
```bash
make
```

# Components
## Naming Server

## Storage Servers

## Clients

# Bibliography and Assumptions
- ctrl-Z to exit a client

# Usage of AI tools